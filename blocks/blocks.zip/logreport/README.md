# Log Report
------------

This plugin available as MOODLE block. 

# Description
-------------
This plugin will make available exisitng log report with easy and quick navigation, without refreshing the page including filters and pagination.

- Hourly, Daily and Monthly hits count of the application.
- Ajax based pagination and filters.
- Quick selection of the filters from dropdown using select2.

# Compatable MOODLE Versions
----------------------------
This plugin compatible with below MOODLE versions.
- v3.2
- v3.3
- v3.4
- v3.5
- v3.6
- v3.7
- v3.8

# Credits
[Datatable](https://datatables.net/)
[Select2](https://select2.org/)

**Thank you**

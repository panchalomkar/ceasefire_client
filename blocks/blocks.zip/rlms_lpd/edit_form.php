<?php
class block_rlms_lpd_edit_form extends block_edit_form {  
    function set_data($defaults) {
        parent::set_data($defaults);
    }
        
}
<?php
/**
 * Version details
 *
 * @package    block_lpd
 * @copyright  
 * @license    
 * @author     Jonatan U.
 */
defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2018031202;        // The current plugin version (Date: YYYYMMDDXX).
$plugin->requires  = 2013110500;        // Requires this Moodle version.
$plugin->component = 'block_rlms_lpd';

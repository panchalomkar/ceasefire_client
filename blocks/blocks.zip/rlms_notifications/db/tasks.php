<?php
$tasks = array(
    array(
        'classname' => 'block_rlms_notifications\task\notify',
        'blocking' => 0,
        'minute' => '*',
        'hour' => '*',
        'day' => '*',
        'dayofweek' => '*',
        'month' => '*'
    )
);

<?php

defined('MOODLE_INTERNAL') || die();

$plugin->version  = 2020040300;
$plugin->requires  = 2014051200;
$plugin->component  = 'block_rlms_notifications';
$plugin->release  = 1;
$plugin->maturity  = MATURITY_STABLE;
$plugin->cron  = 1;

$(function() {
  $('.chart').easyPieChart({
    size: 126,
    barColor: "#6cdddb",
    scaleLength: 0,
    lineWidth: 8,
    trackColor: "#d1d1d1",
    lineCap: "circle",
    animate: 2000,
  });
});

<?php
$string['pluginname'] = 'Social Wall Block';
$string['socialwall'] = 'Social Wall';
$string['Social Wall'] = 'Social Wall';
$string['socialwall:addinstance'] = 'Add a new Social Wall block';
$string['socialwall:myaddinstance'] = 'Add a new Social Wall block to the My Moodle page';
$string['socialwall:viewinstance'] = 'Allow to see Social Wall block';
$string['iframewidth'] = "Width for iFrame";
$string['iframeheight'] = "Height for iFrame";
$string['showscrollbars'] = "Show scroll bars?";
$string['titleblock'] = "Social Wall";
$string['whatdoyouthink'] = "What do you want to share?";
$string['showscrollbars'] = "Show scrollbar?";

$string['What do you want to share?'] = "What do you want to share?";
$string[' Share '] = ' Share ';

$string['Say something...'] = 'Do you want to say something?';

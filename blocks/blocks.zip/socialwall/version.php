<?php
$plugin->version = 2016050601;  // YYYYMMDDHH (year, month, day, 24-hr time)
$plugin->component = 'block_socialwall'; // Full name of the plugin (used for diagnostics)
$plugin->requires  = 2012112900;        // Requires this Moodle version
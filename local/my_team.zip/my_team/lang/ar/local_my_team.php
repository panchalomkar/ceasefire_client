<?php

$string['pluginname'] = 'فريقي';
$string['manage'] = 'إدارة';
$string['manager'] = 'مدير';
$string['assignedusers'] = 'المستخدمين المينين';
$string['availableusers'] = 'المستخدمون المتوفرون';
$string['userassigned'] = 'المستخدم المعيّن';
$string['userremoved'] = 'المستخدم محذوف';
$string['manageteam'] = 'إدارة الفريق';
$string['backtomyteam'] = 'العودة إلى فريقي';
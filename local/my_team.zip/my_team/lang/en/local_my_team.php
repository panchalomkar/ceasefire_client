<?php

$string['pluginname'] = 'My Team';
$string['manage'] = 'Manage';
$string['manager'] = 'Manager';
$string['assignedusers'] = 'Assigned Users';
$string['availableusers'] = 'Available Users';
$string['userassigned'] = 'User Assigned';
$string['userremoved'] = 'User Removed';
$string['manageteam'] = 'Manage Team';
$string['backtomyteam'] = 'Back to My Team';